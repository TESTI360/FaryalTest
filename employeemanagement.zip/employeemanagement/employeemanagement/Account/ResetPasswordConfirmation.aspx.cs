﻿using System.Web.UI;

namespace employeemanagement.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}