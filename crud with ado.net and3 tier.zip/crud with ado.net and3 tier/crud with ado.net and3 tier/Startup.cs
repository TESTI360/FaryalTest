﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(crud_with_ado.net_and3_tier.Startup))]
namespace crud_with_ado.net_and3_tier
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
