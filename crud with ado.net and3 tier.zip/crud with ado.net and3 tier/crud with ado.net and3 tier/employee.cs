﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace crud_with_ado.net_and3_tier
{
    public class employee
    {
        public int empid { get; set; }
        public string name { get; set;  }
    }
}