﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace crud_with_ado.net_and3_tier
{
    public class extendedclass
    {
        public int ObjToInt(object obj)
        {
            int retVal = 0;
            if (obj == null)
            {
                return retVal;
            }
            int.TryParse(obj.ToString(), out retVal);
            return retVal;
        }
    }
}