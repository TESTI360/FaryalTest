﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
namespace crud_with_ado.net_and3_tier
{
    public class DALemployee
    {

        public int CreateEmployee(string empname)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            SqlCommand cmd = new SqlCommand("CRUDemployee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@name", empname);
            cmd.Parameters.AddWithValue("@statementtype","insertemployee");
            cmd.Parameters.Add("@returnvalue",SqlDbType.Int);
            cmd.Parameters["@returnvalue"].Direction = ParameterDirection.Output;
            conn.Open();

            cmd.ExecuteNonQuery();
            conn.Close();
            return (Convert.ToInt32(cmd.Parameters["@returnvalue"].Value));
        }

        public DataTable RetrieveAllEmployees()

        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            SqlCommand cmd = new SqlCommand("CRUDemployee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@statementtype","retrieveallemployees");
             conn.Open();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;

        }
        public object RetrieveSearchedEmployee(int empid)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);


            if (CheckIfExists(empid) == 1)
            {
                SqlCommand cmd = new SqlCommand("CRUDemployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@statementtype", "retrievesearchedemployee");
                cmd.Parameters.AddWithValue("@empid", empid);
                conn.Open();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }
            else
                return -1;
        }



        
        public int CheckIfExists(int empid)
        {
            SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            SqlCommand cmd = new SqlCommand("CRUDemployee",conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@empid",empid);
            cmd.Parameters.AddWithValue("@statementtype","checkifexists");
            cmd.Parameters.Add("@returnvalue",SqlDbType.Int);
            
            cmd.Parameters["@returnvalue"].Direction = ParameterDirection.Output;
            conn.Open();

            cmd.ExecuteNonQuery();
            conn.Close();
            return (Convert.ToInt32(cmd.Parameters["@returnvalue"].Value));

        }
        public void UpdateEmployee(int empid,string empname)
        {
           SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            SqlCommand cmd = new SqlCommand("CRUDemployee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@statementtype", "updateemployee");
            cmd.Parameters.AddWithValue("@empid",empid);
            cmd.Parameters.AddWithValue("@name",empname);

            conn.Open();

            cmd.ExecuteNonQuery();
            conn.Close();
            


        }
        public void DeleteEmployee(int empid)
        {
               SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);

            SqlCommand cmd = new SqlCommand("CRUDemployee", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@statementtype", "deleteemployee");
            cmd.Parameters.AddWithValue("@empid", empid);
           

            conn.Open();

            cmd.ExecuteNonQuery();
            conn.Close();



        }
    }
}