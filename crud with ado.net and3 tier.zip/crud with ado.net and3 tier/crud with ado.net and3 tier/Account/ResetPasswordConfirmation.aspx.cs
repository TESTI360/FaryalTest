﻿using System.Web.UI;

namespace crud_with_ado.net_and3_tier.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}