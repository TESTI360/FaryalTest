﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;


namespace crud_with_linq_to_sql_1
{
    public class DALemployee
    {

        public int CreateEmployee(string empname)
        {
            UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
            int? retval = 0;
            dbcontext.CRUDemployees("insertemployee", null, empname, ref retval);
            return (Convert.ToInt32(retval));

        }

        public DataTable RetrieveAllEmployees()

        {


            UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
            DataTable dt = new DataTable();
            int? empid = 0;
            var result = dbcontext.CRUDemployees("retrieveallemployees", null, null, ref empid);
            extendedclass ec = new extendedclass();
            dt = ec.ObtainDataTableFromIEnumerable(result);

            return dt;
         
        

        }
        public object RetrieveSearchedEmployee(int empid)
        {


            if (CheckIfExists(empid) == 1)
            {

                UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
                DataTable dt = new DataTable();
                int? retval = 0;
                var result = dbcontext.CRUDemployees("retrievesearchedemployee", empid, null, ref retval);
                extendedclass ec = new extendedclass();
                dt = ec.ObtainDataTableFromIEnumerable(result);

                return dt;

            }
            else

                return -1;
        }


      


        public int CheckIfExists(int empid)
        {
            UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
            int? retval = 0;
            dbcontext.CRUDemployees("checkifexists", empid, null,ref retval);
            return (Convert.ToInt32(retval));

        }
        public void UpdateEmployee(int empid, string empname)
        {
            UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
            int? retval = 0;
            dbcontext.CRUDemployees("updateemployee", empid, empname, ref retval);
          



        }
        public void DeleteEmployee(int empid)
        {
            UniAdminLinqtoSQLDataContext dbcontext = new UniAdminLinqtoSQLDataContext();
            int? retval = 0;
            dbcontext.CRUDemployees("deleteemployee", empid, null, ref retval);

        }
    }
}
