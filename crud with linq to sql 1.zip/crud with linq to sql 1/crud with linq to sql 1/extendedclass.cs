﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;

namespace crud_with_linq_to_sql_1
{
    public class extendedclass
    {
        public DataTable ObtainDataTableFromIEnumerable(System.Collections.IEnumerable ien)

        {

            DataTable dt = new DataTable();

            foreach (object obj in ien)

            {

                Type t = obj.GetType();

                PropertyInfo[] pis = t.GetProperties();

                if (dt.Columns.Count == 0)

                {

                    foreach (PropertyInfo pi in pis)

                    {

                        dt.Columns.Add(pi.Name, pi.PropertyType);

                    }

                }

                DataRow dr = dt.NewRow();

                foreach (PropertyInfo pi in pis)

                {

                    object value = pi.GetValue(obj, null);

                    dr[pi.Name] = value;

                }

                dt.Rows.Add(dr);

            }

            return dt;

        }

    }
}