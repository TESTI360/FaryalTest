﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
namespace crud_with_linq_to_sql_1
{
    public class BALemployee
    {
        public int CreateEmployee(string empname)
        {

            if (string.IsNullOrWhiteSpace(empname) == true)

            {
                return -1;
            }
            else
            {
                DALemployee dalemp = new DALemployee();
                return (dalemp.CreateEmployee(empname));
            }





        }
        public DataTable RetrieveAllEmployees()
        {

            DALemployee dalemp = new DALemployee();
            return (dalemp.RetrieveAllEmployees());
        }

        
        public object RetrieveSearchedEmployee(int empid)
        {




            DALemployee dalemp = new DALemployee();
            return (dalemp.RetrieveSearchedEmployee(empid));





        }
        public void UpdateEmployee(int empid, string empname)
        {
            DALemployee dalemp = new DALemployee();
            dalemp.UpdateEmployee(empid, empname);


        }
        public void DeleteEmployee(int empid)
        {
            DALemployee dalemp = new DALemployee();
            dalemp.DeleteEmployee(empid);



        }
    }
}