﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace crud_with_linq_to_sql_1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncreateemp_Click(object sender, EventArgs e)
        {

            BALemployee balemp = new BALemployee();
            int returnedvalue = balemp.CreateEmployee(txtempname.Text);


            if (returnedvalue > 0)
            {
                Page.RegisterClientScriptBlock("message", "<script>alert('Employee Successfully Created! Employee ID is " + returnedvalue + "') </script>");

            }
            else
            {

                Page.RegisterClientScriptBlock("message", "<script>alert('Wrong Inputs!')</script>");
            }


        }
    }
}