﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(crud_with_linq_to_sql_1.Startup))]
namespace crud_with_linq_to_sql_1
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
