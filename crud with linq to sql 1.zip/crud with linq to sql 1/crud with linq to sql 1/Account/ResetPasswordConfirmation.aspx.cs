﻿using System.Web.UI;

namespace crud_with_linq_to_sql_1.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}