﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
namespace crud_with_linq_to_sql_1
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            BALemployee balemp = new BALemployee();
            GridView1.DataSource = balemp.RetrieveAllEmployees();
            GridView1.DataBind();
        }

        protected void btnsearchemp_Click(object sender, EventArgs e)
        {
            BALemployee balemp = new BALemployee();
            object data = balemp.RetrieveSearchedEmployee(Convert.ToInt32(txtsearchemp.Text));
            int n;
            if (int.TryParse(data.ToString(), out n) & (n == -1))
                Page.RegisterClientScriptBlock("message", "<script>alert('Record doesnt exist!')</script>");
            else
            {
                GridView1.DataSource = (DataTable)data;
                GridView1.DataBind();
                btndeleteemp.Visible = true;
                Label1.Visible = true;
                txtupdatename.Visible = true;
                btnupdateemp.Visible = true;

            }




        }

        protected void btnupdateemp_Click(object sender, EventArgs e)
        {

            BALemployee balemp = new BALemployee();
            balemp.UpdateEmployee(Convert.ToInt32(txtsearchemp.Text), txtupdatename.Text);
            Page.RegisterClientScriptBlock("message", "<script>alert('Record Updates Successfully!')</script>");
            btndeleteemp.Visible = false;
            Label1.Visible = false;
            txtupdatename.Visible = false;
            btnupdateemp.Visible = false;
            GridView1.DataSource = balemp.RetrieveAllEmployees();
            GridView1.DataBind();
        }

        protected void btndeleteemp_Click(object sender, EventArgs e)
        {
            BALemployee balemp = new BALemployee();
            balemp.DeleteEmployee(Convert.ToInt32(txtsearchemp.Text));
            Page.RegisterClientScriptBlock("message", "<script>alert('Record Deleted Successfully!')</script>");
            btndeleteemp.Visible = false;
            Label1.Visible = false;
            txtupdatename.Visible = false;
            btnupdateemp.Visible = false;
            GridView1.DataSource = balemp.RetrieveAllEmployees();
            GridView1.DataBind();
        }


    }
}